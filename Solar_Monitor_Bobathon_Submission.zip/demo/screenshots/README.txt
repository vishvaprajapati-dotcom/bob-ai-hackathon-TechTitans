Add at least 3 real screenshots of the running application here, named:
01-home-dashboard.png
02-query-input.png
03-result-output.png
