# src

This directory contains the complete local C++ prototype.

- `solar_monitor.cpp` — image loader, anomaly detector, red-circle annotation, and report generation.
- `generate_demo_image.cpp` — creates a synthetic solar-panel-like PPM image containing an abnormal bright region for testing.
- `.env.example` — placeholder for future service configuration.
