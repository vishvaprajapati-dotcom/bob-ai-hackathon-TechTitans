# Solar Monitor — Solar Panel Fault Detection

## Team
- **Team:** YOUR TEAM NAME
- **Track:** AI
- **Lead:** YOUR NAME
- **Members:** TEAM MEMBER 2, TEAM MEMBER 3

## Problem Statement
Solar panels can develop abnormal regions because of faults, hotspots, cracks, cell damage, dirt, or other physical/thermal issues. Manual inspection can be time-consuming and may make it difficult to consistently identify the most suspicious region.

## Solution
Solar Monitor is a lightweight prototype that takes a solar-panel image, analyzes its pixel information, identifies suspicious high-contrast/abnormal regions, and produces an output image with a **red circle around the detected region**. The implementation intentionally avoids OpenCV so it can be built with a standard C++ compiler and common image-processing code.

## Key Features
1. Load a solar-panel image.
2. Analyze image regions using a simple anomaly score.
3. Select the most suspicious region.
4. Generate an annotated image with a red circle.
5. Generate a text report describing the detected region and score.

## Tech Stack
- C++
- Standard C++ library
- PPM/PGM image processing
- Optional IBM Bob/watsonx integration can be added as a conversational layer around the local detector.

## Repository Structure
```text
src/
  solar_monitor.cpp
  generate_demo_image.cpp
  README.md
docs/
  problem-statement.md
  solution-overview.md
  architecture.md
  setup-guide.md
demo/
  demo-video-link.txt
  live-demo-url.txt
  screenshots/
presentation/
  slides.md
submission.yaml
README.md
CONTRIBUTING.md
.gitignore
```

## How to Run
See [docs/setup-guide.md](docs/setup-guide.md).

Quick build:
```bash
g++ -std=c++17 -O2 src/solar_monitor.cpp -o solar_monitor.exe
```

Run:
```bash
solar_monitor.exe input.ppm output.ppm report.txt
```

A demo image can be generated with:
```bash
g++ -std=c++17 -O2 src/generate_demo_image.cpp -o generate_demo_image.exe
generate_demo_image.exe demo_input.ppm
solar_monitor.exe demo_input.ppm demo_output.ppm report.txt
```

## Demo
The program creates an annotated output image and a text report. Add three real screenshots of the running application under `demo/screenshots/` before submission, as required by the hackathon template.

## Known Limitations
- The prototype uses a simple image-analysis heuristic rather than a trained computer-vision model.
- PPM input/output is used to avoid third-party image libraries.
- The prototype should be validated against real solar-panel datasets before production use.
- The red circle indicates a suspicious region and is not a guarantee of a physical defect.

## What We're Most Proud Of
The prototype demonstrates the complete path from image input to an interpretable visual result without requiring OpenCV. The output is easy for a human operator to understand because the suspected region is explicitly highlighted.
