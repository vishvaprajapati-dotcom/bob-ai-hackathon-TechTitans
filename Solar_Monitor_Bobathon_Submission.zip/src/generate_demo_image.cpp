#include <fstream>
#include <iostream>
#include <string>
#include <vector>

struct Pixel { unsigned char r, g, b; };

int main(int argc, char* argv[]) {
    std::string out = argc >= 2 ? argv[1] : "demo_input.ppm";
    const int W = 800, H = 500;
    std::vector<Pixel> p(static_cast<size_t>(W) * H);

    for (int y = 0; y < H; ++y) {
        for (int x = 0; x < W; ++x) {
            // Dark blue-gray solar-panel background.
            unsigned char base = static_cast<unsigned char>(35 + (x + y) % 12);
            Pixel q{static_cast<unsigned char>(base * 0.45),
                    static_cast<unsigned char>(base * 0.65),
                    static_cast<unsigned char>(base)};
            // Grid-like cell pattern.
            if ((x / 100 + y / 100) % 2 == 0) {
                q.r += 8; q.g += 8; q.b += 8;
            }

            // Synthetic abnormal bright region around (590, 250).
            int dx = x - 590, dy = y - 250;
            if (dx * dx + dy * dy < 42 * 42) {
                q = {245, 225, 90};
            }
            p[static_cast<size_t>(y) * W + x] = q;
        }
    }

    std::ofstream f(out, std::ios::binary);
    if (!f) return 1;
    f << "P6\n" << W << " " << H << "\n255\n";
    f.write(reinterpret_cast<const char*>(p.data()),
            static_cast<std::streamsize>(p.size() * sizeof(Pixel)));

    std::cout << "Generated " << out << "\n";
    return 0;
}
